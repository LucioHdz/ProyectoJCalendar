package com.tesji.vista;

import javax.swing.JOptionPane;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JCalendar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Calendar;

public class CalendarioView extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalendarioView frame = new CalendarioView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CalendarioView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 622, 352);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JCalendar calendar = new JCalendar();
		calendar.setBounds(25, 0, 559, 225);
		contentPane.add(calendar);
		
		JButton btnMostrarFechaCompleta = new JButton("Mostrar fecha completa");
		btnMostrarFechaCompleta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(rootPane,"Fecha seleccionada: " + calendar.getDate());
			}
		});
		btnMostrarFechaCompleta.setBounds(25, 267, 202, 25);
		contentPane.add(btnMostrarFechaCompleta);
		
		JButton btnMostrarMs = new JButton("Mostrar mes");
		btnMostrarMs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(rootPane, "El mes seleccionado es: " +
						(calendar.getCalendar().get(Calendar.MONTH)+1));
			}
		});
		btnMostrarMs.setBounds(253, 267, 129, 25);
		contentPane.add(btnMostrarMs);
		
		JButton btnMostrarDia = new JButton("Mostrar dia");
		btnMostrarDia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(rootPane, "El día seleccionado es: " +
						calendar.getCalendar().get(Calendar.DAY_OF_MONTH));
			}
		});
		btnMostrarDia.setBounds(423, 267, 117, 25);
		contentPane.add(btnMostrarDia);
		setLocationRelativeTo(null);
	}
}
