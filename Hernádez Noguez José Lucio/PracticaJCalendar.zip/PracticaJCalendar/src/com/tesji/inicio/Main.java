package com.tesji.inicio;

import com.tesji.vista.CalendarioView;

public class Main {

	public static void main(String[] args) {
		new CalendarioView().setVisible(true);
	}
	

}
